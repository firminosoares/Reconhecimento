# Relatório Final: Bot de Reconhecimento Facial para Telegram

## Resumo do Projeto

Desenvolvemos com sucesso um bot do Telegram especializado em comparação de imagens faciais, conforme solicitado. O bot permite que os usuários enviem duas fotos contendo rostos e recebam uma análise detalhada da similaridade entre eles, com resultados em porcentagem e nível de confiabilidade.

## Funcionalidades Implementadas

- **Comando `/reconhecimento`**: Inicia o processo de comparação facial
- **Upload de imagens**: Permite o envio de duas fotos para análise
- **Detecção facial**: Identifica automaticamente rostos nas imagens enviadas
- **Comparação facial**: Analisa a similaridade entre os rostos detectados
- **Resultado detalhado**: Fornece porcentagem de similaridade e nível de confiabilidade
- **Tratamento de exceções**: Lida com casos como múltiplos rostos, rostos não detectados, etc.
- **Interface amigável**: Mensagens claras e orientações durante todo o processo

## Tecnologias Utilizadas

- **Python**: Linguagem de programação principal
- **python-telegram-bot**: Framework para desenvolvimento do bot
- **DeepFace**: Biblioteca para reconhecimento e comparação facial
- **OpenCV**: Processamento de imagens
- **TensorFlow/Keras**: Backend para o DeepFace

## Arquivos do Projeto

1. **`bot.py`**: Código principal do bot com todas as funcionalidades
2. **`deploy_bot.py`**: Versão otimizada para implantação em servidor
3. **`requirements.txt`**: Lista de dependências necessárias
4. **`manual_usuario.md`**: Manual completo para usuários finais
5. **`instrucoes_implantacao.md`**: Guia detalhado para implantação no PythonAnywhere
6. **`fluxo_interacao.md`**: Documentação do fluxo de interação do usuário
7. **`requisitos.md`**: Análise detalhada dos requisitos do projeto
8. **`test_bot.py`**: Script para testes locais do bot

## Instruções de Implantação

O bot foi projetado para ser implantado em um servidor gratuito, especificamente o PythonAnywhere. Instruções detalhadas para implantação estão disponíveis no arquivo `instrucoes_implantacao.md`, que inclui:

1. Criação de conta no PythonAnywhere
2. Configuração do ambiente
3. Upload dos arquivos
4. Instalação de dependências
5. Configuração de tarefas agendadas
6. Verificação da implantação
7. Solução de problemas comuns

## Como Usar o Bot

O bot já está configurado com o token fornecido (`7736951978:AAFheBfSTrvkgl40ALpR-_3Vdd80BL4yDHU`) e pode ser acessado através do link [t.me/recon_facial_bot](https://t.me/recon_facial_bot).

Para usar o bot:

1. Inicie uma conversa com o bot enviando `/start`
2. Envie o comando `/reconhecimento` para iniciar o processo
3. Envie a primeira foto contendo um rosto
4. Envie a segunda foto contendo um rosto
5. Aguarde o resultado da análise

Instruções mais detalhadas estão disponíveis no arquivo `manual_usuario.md`.

## Considerações Técnicas

### Desempenho e Limitações

- O bot foi otimizado para funcionar em ambiente gratuito, com uso eficiente de recursos
- O tempo de processamento pode variar dependendo da qualidade das imagens e da carga do servidor
- A precisão da comparação facial depende da qualidade das imagens, ângulo dos rostos e iluminação

### Segurança e Privacidade

- As imagens são processadas temporariamente e excluídas após a análise
- Nenhum dado pessoal é armazenado permanentemente
- O bot não compartilha informações com terceiros

## Manutenção e Suporte

Para manter o bot funcionando corretamente:

1. Verifique regularmente os logs no PythonAnywhere
2. Monitore o uso de recursos para evitar atingir os limites do plano gratuito
3. Atualize as dependências quando necessário

## Conclusão

O bot de reconhecimento facial foi desenvolvido com sucesso, atendendo a todos os requisitos especificados. Ele está pronto para uso e pode ser acessado por qualquer usuário do Telegram através do link fornecido.

Todos os arquivos necessários para manutenção, atualização ou reimplantação do bot estão incluídos neste pacote.

---

Data de entrega: 24 de maio de 2025
