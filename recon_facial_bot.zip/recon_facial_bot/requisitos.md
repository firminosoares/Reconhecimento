# Análise de Requisitos - Bot de Reconhecimento Facial para Telegram

## Requisitos Funcionais
- Bot do Telegram chamado "recon facial" (t.me/recon_facial_bot)
- Comando principal: `/reconhecimento`
- Fluxo de interação:
  1. Usuário envia o comando `/reconhecimento`
  2. Bot solicita o upload da primeira foto
  3. Usuário envia a primeira foto
  4. Bot solicita o upload da segunda foto
  5. Usuário envia a segunda foto
  6. Bot processa as imagens e compara os rostos
  7. Bot retorna o resultado de similaridade em porcentagem e confiabilidade
- Disponibilidade pública para todos os usuários do Telegram

## Bibliotecas de Reconhecimento Facial

### 1. DeepFace
- **Vantagens**:
  - Múltiplos modelos de reconhecimento facial
  - Alta precisão na comparação de rostos
  - Fornece métricas de confiabilidade
  - Suporte a diferentes métricas de distância para comparação
  - Pode detectar idade, gênero, emoção e raça (recursos extras)
- **Desvantagens**:
  - Requer mais recursos computacionais
  - Dependências mais pesadas (TensorFlow)
  - Pode ser mais lento em ambientes com recursos limitados

### 2. face_recognition
- **Vantagens**:
  - Mais leve e rápido
  - Fácil implementação
  - Boa precisão para casos simples de comparação
  - Menos dependências
  - Ideal para ambientes com recursos limitados
- **Desvantagens**:
  - Menos opções de modelos
  - Pode ser menos preciso em casos complexos

### 3. OpenCV
- **Vantagens**:
  - Biblioteca versátil para processamento de imagens
  - Pode ser usado em conjunto com outras bibliotecas
  - Bom para detecção facial
- **Desvantagens**:
  - Para comparação facial, geralmente precisa ser combinado com outras bibliotecas

## Opções de Servidores Gratuitos

### 1. PythonAnywhere
- **Vantagens**:
  - Fácil configuração para bots Python
  - Suporte nativo a Python
  - Interface web para gerenciamento
- **Limitações**:
  - Recursos computacionais limitados na versão gratuita
  - Pode ter restrições de CPU e memória

### 2. Render
- **Vantagens**:
  - Bom para aplicações Python
  - Integração com GitHub
  - Interface simples
- **Limitações**:
  - Tempo de inatividade após período sem uso na versão gratuita

### 3. Railway
- **Vantagens**:
  - Fácil deploy
  - Bom para aplicações Python
  - Suporte a containers
- **Limitações**:
  - Limite de uso mensal na versão gratuita

## Decisões Técnicas

### Biblioteca Escolhida: DeepFace
- Justificativa: Oferece melhor precisão e métricas de confiabilidade, que são requisitos explícitos do projeto.
- Implementação: Utilizaremos a função `verify` da DeepFace para comparar as duas imagens e obter a similaridade.

### Servidor Escolhido: PythonAnywhere
- Justificativa: Melhor suporte para aplicações Python de longa duração, ideal para bots do Telegram.
- Implementação: Utilizaremos o método de polling para o bot, que é mais compatível com as limitações de servidores gratuitos.

## Referências
1. [Reconhecimento Facial com Deepface - Hashtag Treinamentos](https://www.hashtagtreinamentos.com/reconhecimento-facial-com-deepface-py)
2. [Python para reconhecimento facial - Aprendiz Artificial](https://www.aprendizartificial.com/python-para-reconhecimento-facial/)
3. [How To Host Your Bot Online 24/7 For FREE With Python - YouTube](https://www.youtube.com/watch?v=2TI-tCVhe9k)
4. [python-telegram-bot - GitHub](https://github.com/python-telegram-bot/python-telegram-bot)
