#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para testar o bot de reconhecimento facial localmente
Este script simula o envio de imagens e testa as funções de comparação facial
"""

import os
import cv2
import numpy as np
from deepface import DeepFace
import logging

# Configuração de logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def test_face_detection(image_path):
    """Testa a detecção de rostos em uma imagem"""
    logger.info(f"Testando detecção facial em: {image_path}")
    
    try:
        # Verifica se o arquivo existe
        if not os.path.exists(image_path):
            logger.error(f"Arquivo não encontrado: {image_path}")
            return False, "Arquivo não encontrado"
        
        # Carrega a imagem
        img = cv2.imread(image_path)
        if img is None:
            logger.error(f"Não foi possível carregar a imagem: {image_path}")
            return False, "Erro ao carregar imagem"
        
        # Detecta rostos na imagem
        faces = DeepFace.extract_faces(img_path=image_path, enforce_detection=False)
        
        if len(faces) == 0:
            logger.warning(f"Nenhum rosto detectado em: {image_path}")
            return False, "Nenhum rosto detectado"
        
        if len(faces) > 1:
            logger.warning(f"Múltiplos rostos ({len(faces)}) detectados em: {image_path}")
            return False, f"Múltiplos rostos ({len(faces)}) detectados"
        
        logger.info(f"Detecção facial bem-sucedida em: {image_path}")
        return True, "Rosto detectado com sucesso"
    
    except Exception as e:
        logger.error(f"Erro durante a detecção facial: {e}")
        return False, f"Erro: {str(e)}"

def test_face_comparison(img1_path, img2_path):
    """Testa a comparação facial entre duas imagens"""
    logger.info(f"Testando comparação facial entre: {img1_path} e {img2_path}")
    
    try:
        # Verifica se os arquivos existem
        if not os.path.exists(img1_path):
            logger.error(f"Arquivo não encontrado: {img1_path}")
            return False, "Primeira imagem não encontrada"
        
        if not os.path.exists(img2_path):
            logger.error(f"Arquivo não encontrado: {img2_path}")
            return False, "Segunda imagem não encontrada"
        
        # Compara as duas imagens
        resultado = DeepFace.verify(
            img1_path=img1_path,
            img2_path=img2_path,
            enforce_detection=False,
            model_name="VGG-Face"
        )
        
        # Extrai os resultados
        verificado = resultado["verified"]
        distancia = resultado["distance"]
        
        # Calcula a similaridade em porcentagem
        similaridade = max(0, min(100, (1 - distancia) * 100))
        
        # Determina o nível de confiabilidade
        if distancia < 0.4:
            confiabilidade = "Alta"
        elif distancia < 0.6:
            confiabilidade = "Média"
        else:
            confiabilidade = "Baixa"
        
        logger.info(f"Comparação concluída: Similaridade={similaridade:.2f}%, Confiabilidade={confiabilidade}")
        return True, {
            "verificado": verificado,
            "similaridade": similaridade,
            "confiabilidade": confiabilidade,
            "distancia": distancia
        }
    
    except Exception as e:
        logger.error(f"Erro durante a comparação facial: {e}")
        return False, f"Erro: {str(e)}"

def main():
    """Função principal para testar as funcionalidades do bot"""
    logger.info("Iniciando testes do bot de reconhecimento facial")
    
    # Diretório para imagens de teste
    test_dir = os.path.join(os.getcwd(), "test_images")
    os.makedirs(test_dir, exist_ok=True)
    
    # Cria imagens de teste simples para verificar se o código está funcionando
    # (Estas imagens não são adequadas para testes reais de reconhecimento facial)
    test_img1 = os.path.join(test_dir, "test1.jpg")
    test_img2 = os.path.join(test_dir, "test2.jpg")
    
    # Cria imagens de teste simples se não existirem
    if not os.path.exists(test_img1):
        img1 = np.ones((300, 300, 3), dtype=np.uint8) * 255  # Imagem branca
        cv2.circle(img1, (150, 150), 100, (0, 0, 0), -1)  # Círculo preto
        cv2.circle(img1, (120, 120), 10, (255, 255, 255), -1)  # Olho esquerdo
        cv2.circle(img1, (180, 120), 10, (255, 255, 255), -1)  # Olho direito
        cv2.ellipse(img1, (150, 180), (50, 20), 0, 0, 180, (255, 255, 255), -1)  # Boca
        cv2.imwrite(test_img1, img1)
    
    if not os.path.exists(test_img2):
        img2 = np.ones((300, 300, 3), dtype=np.uint8) * 255  # Imagem branca
        cv2.circle(img2, (150, 150), 100, (0, 0, 0), -1)  # Círculo preto
        cv2.circle(img2, (120, 120), 15, (255, 255, 255), -1)  # Olho esquerdo maior
        cv2.circle(img2, (180, 120), 15, (255, 255, 255), -1)  # Olho direito maior
        cv2.ellipse(img2, (150, 190), (60, 25), 0, 0, 180, (255, 255, 255), -1)  # Boca diferente
        cv2.imwrite(test_img2, img2)
    
    logger.info("Imagens de teste criadas")
    
    # Testa a detecção facial
    logger.info("=== Testando detecção facial ===")
    success1, msg1 = test_face_detection(test_img1)
    logger.info(f"Teste 1: {'PASSOU' if success1 else 'FALHOU'} - {msg1}")
    
    success2, msg2 = test_face_detection(test_img2)
    logger.info(f"Teste 2: {'PASSOU' if success2 else 'FALHOU'} - {msg2}")
    
    # Testa a comparação facial
    if success1 and success2:
        logger.info("=== Testando comparação facial ===")
        success3, result = test_face_comparison(test_img1, test_img2)
        
        if success3:
            logger.info(f"Teste 3: PASSOU")
            logger.info(f"Resultado da comparação:")
            logger.info(f"  - Verificado: {result['verificado']}")
            logger.info(f"  - Similaridade: {result['similaridade']:.2f}%")
            logger.info(f"  - Confiabilidade: {result['confiabilidade']}")
            logger.info(f"  - Distância: {result['distancia']}")
        else:
            logger.info(f"Teste 3: FALHOU - {result}")
    
    logger.info("Testes concluídos")

if __name__ == "__main__":
    main()
