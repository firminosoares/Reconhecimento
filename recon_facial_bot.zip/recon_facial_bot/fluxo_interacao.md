# Fluxo de Interação do Bot de Reconhecimento Facial

## Visão Geral
Este documento detalha o fluxo de interação entre o usuário e o bot de reconhecimento facial no Telegram, desde o início da conversa até a apresentação dos resultados de comparação facial.

## Fluxo Principal

### 1. Início da Interação
- **Ação do Usuário**: Inicia conversa com o bot ou envia o comando `/start`
- **Resposta do Bot**: 
  ```
  Olá! Eu sou o Recon Facial Bot, especialista em comparação de imagens faciais.
  
  Para iniciar uma comparação, envie o comando /reconhecimento.
  
  Para obter ajuda, envie /ajuda.
  ```

### 2. Comando de Ajuda
- **Ação do Usuário**: Envia o comando `/ajuda`
- **Resposta do Bot**:
  ```
  Como usar o Recon Facial Bot:
  
  1. Envie o comando /reconhecimento
  2. Envie a primeira foto com um rosto
  3. Envie a segunda foto com um rosto
  4. Aguarde o resultado da comparação
  
  O resultado mostrará a porcentagem de similaridade entre os rostos e o nível de confiabilidade da análise.
  ```

### 3. Início do Reconhecimento
- **Ação do Usuário**: Envia o comando `/reconhecimento`
- **Resposta do Bot**:
  ```
  Vamos iniciar a comparação facial!
  
  Por favor, envie a primeira foto contendo um rosto.
  ```
- **Estado do Bot**: Aguardando primeira foto

### 4. Recebimento da Primeira Foto
- **Ação do Usuário**: Envia a primeira foto
- **Processamento do Bot**: 
  1. Verifica se a imagem contém um rosto detectável
  2. Salva a imagem temporariamente
- **Resposta do Bot (Sucesso)**:
  ```
  Primeira foto recebida com sucesso!
  
  Agora, por favor, envie a segunda foto contendo um rosto para comparação.
  ```
- **Resposta do Bot (Erro - Rosto não detectado)**:
  ```
  Não foi possível detectar um rosto na imagem enviada.
  
  Por favor, envie outra foto onde o rosto esteja claramente visível.
  ```
- **Estado do Bot**: Aguardando segunda foto (se sucesso) ou aguardando nova primeira foto (se erro)

### 5. Recebimento da Segunda Foto
- **Ação do Usuário**: Envia a segunda foto
- **Processamento do Bot**:
  1. Verifica se a imagem contém um rosto detectável
  2. Salva a imagem temporariamente
- **Resposta do Bot (Sucesso)**:
  ```
  Segunda foto recebida com sucesso!
  
  Processando a comparação facial... Por favor, aguarde alguns instantes.
  ```
- **Resposta do Bot (Erro - Rosto não detectado)**:
  ```
  Não foi possível detectar um rosto na imagem enviada.
  
  Por favor, envie outra foto onde o rosto esteja claramente visível.
  ```
- **Estado do Bot**: Processando comparação (se sucesso) ou aguardando nova segunda foto (se erro)

### 6. Processamento e Resultado
- **Processamento do Bot**:
  1. Utiliza a biblioteca DeepFace para comparar as duas imagens
  2. Calcula a similaridade e o nível de confiabilidade
  3. Formata o resultado para apresentação
- **Resposta do Bot (Sucesso)**:
  ```
  ✅ Análise concluída!
  
  📊 Resultado da comparação facial:
  
  Similaridade: XX.XX%
  Confiabilidade: Alta/Média/Baixa
  
  Para realizar uma nova comparação, envie o comando /reconhecimento novamente.
  ```
- **Resposta do Bot (Erro no processamento)**:
  ```
  ❌ Ocorreu um erro durante a comparação das imagens.
  
  Isso pode acontecer devido a:
  - Baixa qualidade das imagens
  - Ângulos muito diferentes dos rostos
  - Iluminação inadequada
  
  Por favor, tente novamente com outras fotos usando o comando /reconhecimento.
  ```
- **Estado do Bot**: Pronto para nova interação

## Tratamento de Exceções

### Timeout
- Se o usuário não enviar uma foto dentro de um tempo determinado (ex: 5 minutos):
  ```
  O tempo para envio da foto expirou.
  
  Para iniciar uma nova comparação, envie o comando /reconhecimento.
  ```

### Formato Inválido
- Se o usuário enviar um arquivo que não seja uma imagem:
  ```
  Por favor, envie apenas arquivos de imagem (jpg, jpeg, png).
  
  Para continuar, envie uma foto válida.
  ```

### Cancelamento
- **Ação do Usuário**: Envia o comando `/cancelar` durante o processo
- **Resposta do Bot**:
  ```
  Processo de comparação cancelado.
  
  Para iniciar uma nova comparação, envie o comando /reconhecimento.
  ```

### Múltiplos Rostos
- Se a imagem contiver mais de um rosto:
  ```
  Detectei múltiplos rostos na imagem. Para uma comparação mais precisa, envie uma foto contendo apenas um rosto.
  
  Por favor, envie outra imagem.
  ```

## Métricas de Confiabilidade

A confiabilidade será determinada com base nos seguintes critérios:
- **Alta**: Imagens de boa qualidade, ângulos similares, boa iluminação
- **Média**: Algumas diferenças de ângulo, iluminação ou qualidade
- **Baixa**: Grandes diferenças de ângulo, iluminação precária ou baixa qualidade

## Diagrama de Estados
```
[Início] -> [Aguardando Comando] -> [Aguardando Primeira Foto] -> 
[Aguardando Segunda Foto] -> [Processando] -> [Exibindo Resultado] -> [Aguardando Comando]
```

## Considerações Técnicas
- Todas as imagens serão processadas e armazenadas temporariamente
- As imagens serão excluídas após o processamento para economia de espaço
- O processamento será otimizado para funcionar dentro das limitações de recursos do servidor gratuito
