# Manual do Bot de Reconhecimento Facial para Telegram

## Visão Geral

O Bot de Reconhecimento Facial para Telegram (t.me/recon_facial_bot) é uma solução especializada em comparação de imagens faciais. O bot permite que os usuários enviem duas fotos contendo rostos e recebam uma análise de similaridade entre eles, com resultados em porcentagem e nível de confiabilidade.

## Funcionalidades

- Comando `/reconhecimento` para iniciar o processo de comparação
- Upload e processamento de duas imagens contendo rostos
- Detecção automática de rostos nas imagens
- Análise de similaridade facial com resultado em porcentagem
- Avaliação do nível de confiabilidade da análise (Alta, Média, Baixa)
- Tratamento de erros e exceções (múltiplos rostos, rostos não detectados, etc.)

## Como Usar

1. Inicie uma conversa com o bot: [t.me/recon_facial_bot](https://t.me/recon_facial_bot)
2. Envie o comando `/start` para receber a mensagem de boas-vindas
3. Envie o comando `/reconhecimento` para iniciar o processo de comparação
4. Envie a primeira foto contendo um rosto
5. Envie a segunda foto contendo um rosto
6. Aguarde o resultado da análise

## Comandos Disponíveis

- `/start` - Inicia a conversa com o bot e exibe a mensagem de boas-vindas
- `/ajuda` - Exibe instruções detalhadas sobre como usar o bot
- `/reconhecimento` - Inicia o processo de comparação facial
- `/cancelar` - Cancela o processo atual de comparação

## Requisitos para as Imagens

Para obter os melhores resultados, as imagens enviadas devem atender aos seguintes requisitos:

- Conter apenas um rosto claramente visível
- Boa iluminação
- Resolução adequada (não muito baixa)
- Rosto em posição frontal ou com ângulo similar nas duas fotos

## Interpretação dos Resultados

### Similaridade

O resultado da similaridade é apresentado em porcentagem, onde:
- 100% indica rostos idênticos
- 0% indica rostos completamente diferentes

### Confiabilidade

O nível de confiabilidade é classificado como:
- **Alta**: Análise realizada com alta precisão, resultado confiável
- **Média**: Análise realizada com precisão moderada, resultado aceitável
- **Baixa**: Análise realizada com baixa precisão, resultado pode não ser confiável

## Limitações

- O bot pode ter dificuldades com imagens de baixa qualidade
- Ângulos muito diferentes entre os rostos podem reduzir a precisão
- Iluminação inadequada pode afetar os resultados
- O processamento pode ser mais lento em momentos de alto tráfego

## Privacidade e Segurança

- As imagens enviadas são processadas temporariamente e excluídas após a análise
- Nenhum dado pessoal é armazenado permanentemente
- O bot não compartilha informações com terceiros

## Suporte Técnico

Em caso de problemas ou dúvidas, entre em contato com o administrador do bot.

---

Desenvolvido com Python, python-telegram-bot e DeepFace.
