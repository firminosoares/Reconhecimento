# Instruções para Implantação do Bot no PythonAnywhere

Este documento contém as instruções detalhadas para implantar o bot de reconhecimento facial no PythonAnywhere, um serviço de hospedagem gratuito para aplicações Python.

## Pré-requisitos

- Conta no PythonAnywhere (gratuita)
- Token do bot do Telegram (já configurado: `7736951978:AAFheBfSTrvkgl40ALpR-_3Vdd80BL4yDHU`)
- Arquivos do projeto (`deploy_bot.py` e dependências)

## Passos para Implantação

### 1. Criar uma conta no PythonAnywhere

1. Acesse [www.pythonanywhere.com](https://www.pythonanywhere.com)
2. Clique em "Pricing & Signup" e escolha o plano gratuito "Beginner"
3. Preencha as informações necessárias e crie sua conta

### 2. Configurar o ambiente

1. Após fazer login, acesse o Dashboard
2. Clique em "Files" no menu superior
3. Crie uma nova pasta para o projeto: `mkdir recon_facial_bot`
4. Entre na pasta: `cd recon_facial_bot`

### 3. Fazer upload dos arquivos

1. No menu "Files", clique em "Upload a file"
2. Faça upload dos seguintes arquivos:
   - `deploy_bot.py` (renomeie para `bot.py`)
   - `requirements.txt` (contendo as dependências)

### 4. Criar o arquivo requirements.txt

Crie um arquivo `requirements.txt` com o seguinte conteúdo:

```
python-telegram-bot==22.1
deepface==0.0.93
opencv-python-headless==4.11.0.86
tf-keras==2.19.0
```

Nota: Usamos `opencv-python-headless` em vez de `opencv-python` para evitar problemas com dependências gráficas no servidor.

### 5. Configurar um ambiente virtual

1. No Dashboard, clique em "Consoles"
2. Inicie um novo console Bash
3. Execute os seguintes comandos:

```bash
cd recon_facial_bot
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 6. Configurar uma tarefa agendada

1. No Dashboard, clique em "Tasks"
2. Na seção "Schedule", configure uma nova tarefa para executar a cada hora:

```bash
cd /home/SEU_USUARIO/recon_facial_bot && source venv/bin/activate && python bot.py
```

Substitua `SEU_USUARIO` pelo seu nome de usuário no PythonAnywhere.

### 7. Configurar um serviço Always-On (opcional, para planos pagos)

Se você tiver um plano pago, pode configurar um serviço Always-On:

1. No Dashboard, clique em "Web"
2. Clique em "Add a new web app"
3. Escolha "Manual configuration" e selecione Python 3.9
4. Configure o caminho para o arquivo WSGI como `/home/SEU_USUARIO/recon_facial_bot/wsgi.py`

### 8. Criar um arquivo wsgi.py (para planos pagos)

```python
import sys
import os
import threading
import time

# Adiciona o diretório do projeto ao path
path = '/home/SEU_USUARIO/recon_facial_bot'
if path not in sys.path:
    sys.path.append(path)

# Importa o bot
from bot import main

# Função para executar o bot em uma thread separada
def run_bot():
    main()

# Inicia o bot em uma thread separada
bot_thread = threading.Thread(target=run_bot)
bot_thread.daemon = True
bot_thread.start()

# Função WSGI simples para manter o serviço ativo
def application(environ, start_response):
    start_response('200 OK', [('Content-Type', 'text/html')])
    return [b'Bot de reconhecimento facial em execucao']
```

## Verificação da Implantação

1. Acesse o bot no Telegram: [t.me/recon_facial_bot](https://t.me/recon_facial_bot)
2. Envie o comando `/start` para verificar se o bot está respondendo
3. Teste o fluxo completo com o comando `/reconhecimento`

## Solução de Problemas

### O bot não responde

1. Verifique os logs no PythonAnywhere:
   - No Dashboard, clique em "Files"
   - Navegue até a pasta do projeto
   - Verifique o arquivo `bot.log`

2. Verifique se a tarefa agendada está sendo executada:
   - No Dashboard, clique em "Tasks"
   - Verifique o status da última execução

### Erros de dependências

1. Verifique se todas as dependências foram instaladas corretamente:
   ```bash
   source venv/bin/activate
   pip list
   ```

2. Tente reinstalar as dependências:
   ```bash
   pip install --upgrade -r requirements.txt
   ```

## Manutenção

- Verifique regularmente os logs para garantir que o bot esteja funcionando corretamente
- Monitore o uso de recursos no PythonAnywhere para evitar atingir os limites do plano gratuito
- Considere fazer backup dos arquivos importantes periodicamente
